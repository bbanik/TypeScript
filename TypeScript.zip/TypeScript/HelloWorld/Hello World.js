function Hello(person) {
    return "Hello " + person;
}
console.log(Hello("SharePoint Team"));
