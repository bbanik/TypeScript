export{}
function Hello(person: string)
{
    return "Hello "+ person;
}

console.log(Hello("SharePoint Team"));