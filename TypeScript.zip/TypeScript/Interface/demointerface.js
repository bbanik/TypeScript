
function greetings(employee) {
    return "Hello" + employee.firstName;
}
var p = {
    firstName: "Biswanath",
    lastName: "Banik",
    xyz: 1
};
console.log(greetings(p));
